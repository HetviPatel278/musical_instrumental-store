package com.example.ecommerce;

import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class editadap extends FirebaseRecyclerAdapter<addata,editadap.myviewholder> {


    DatabaseReference reference;
    public editadap(@NonNull FirebaseRecyclerOptions<addata> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull final editadap.myviewholder holder, final int position, @NonNull final addata model) {
        reference= FirebaseDatabase.getInstance().getReference().child("products");
        holder.name.setText(model.getName());
        holder.price.setText(model.getPrice());
        holder.desc.setText(model.getDescription());
        holder.stoavail.setText(model.getStock());
        reference.child(model.getProdid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    String img=snapshot.child("image").getValue().toString();
                    Glide.with(holder.i1.getContext()).load(img).into(holder.i1);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        holder.v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),update.class);
                intent.putExtra("prodid",getRef(position).getKey());
                v.getContext().startActivity(intent);
            }
        });
        holder.v.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final CharSequence[] items = {"Delete"};

                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());

                builder.setTitle("Select The Action");
                builder.setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {
                     String txt=model.getProdid();
                        reference= FirebaseDatabase.getInstance().getReference("products").child(txt);
                        reference.removeValue();
                    }
                });
                builder.show();
                return true;
            }
        });


    }

    @NonNull
    @Override
    public editadap.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.editrow,parent,false);
        return new editadap.myviewholder(view);
    }

    class myviewholder extends RecyclerView.ViewHolder{
        ImageView i1;
        TextView name,price,desc,stoavail;
        View v;
        public myviewholder(@NonNull final View itemView) {
            super(itemView);

            name=(TextView)itemView.findViewById(R.id.prod_nam);
            price=(TextView)itemView.findViewById(R.id.price);
            desc=(TextView)itemView.findViewById(R.id.prod_desc);
            stoavail=(TextView)itemView.findViewById(R.id.avails);
            i1=(ImageView)itemView.findViewById(R.id.img);
            v=itemView;

        }

    }
}
