package com.example.ecommerce;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
TextView btn_reg,regseller,slogin;
EditText userid,userpass;
Button login;


    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_reg=(TextView) findViewById(R.id.custreg);
        userid=(EditText)findViewById(R.id.userid);
        userpass=(EditText)findViewById(R.id.userpass);
        login=(Button)findViewById(R.id.login);
        firebaseAuth=FirebaseAuth.getInstance();
        slogin=(TextView)findViewById(R.id.slogin);
        btn_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
        slogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                slogin();
            }
        });
    }
    public void login(){
        String u_id=userid.getText().toString().trim();
        String u_pass=userpass.getText().toString().trim();

        if(u_id.isEmpty()){
            userid.setError("please enter email");
            userid.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(u_id).matches()){
            userid.setError("please enter valid email address");
            userid.requestFocus();
            return;
        }
        if(u_pass.isEmpty()){
            userpass.setError("enter password");
            userpass.requestFocus();
            return;
        }
        if(u_pass.length()<6){
            userpass.setError("minimum length of password should be 6");
            userpass.requestFocus();
            return;

        }
        firebaseAuth.signInWithEmailAndPassword(u_id, u_pass)
                .addOnCompleteListener( new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (!task.isSuccessful()) {
                            Toast.makeText(MainActivity.this, "entered data is incorrect", Toast.LENGTH_SHORT).show();

                        }
                        else {

                            Toast.makeText(MainActivity.this, "login successfully done", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(MainActivity.this, userpage.class));
                        }
                    }
                });
    }
    public void register(){
        Intent intent = new Intent(this, register.class);
        startActivity(intent);
    }

    public void slogin(){
        Intent intent = new Intent(this, sellerlogin.class);
        startActivity(intent);
    }
}
