package com.example.ecommerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class orderpage extends AppCompatActivity {
RecyclerView recycle;
orderadap adap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orderpage);
        recycle=(RecyclerView)findViewById(R.id.recycle);
        recycle.setLayoutManager(new LinearLayoutManager(this));
        LinearLayoutManager layoutManager=
                new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,true);
        layoutManager.setStackFromEnd(true);
        recycle.setLayoutManager(layoutManager);
        FirebaseRecyclerOptions<addata> opt =
                new FirebaseRecyclerOptions.Builder<addata>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("orders"), addata.class)
                        .build();
        adap=new orderadap(opt);
        recycle.setAdapter(adap);

    }

    @Override
    protected void onStart() {
        super.onStart();
        adap.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adap.stopListening();
    }
}
