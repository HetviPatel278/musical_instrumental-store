package com.example.ecommerce;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class myordadap extends FirebaseRecyclerAdapter<addata,myordadap.myviewholder> {
    DatabaseReference reference,ref;
    FirebaseAuth Auth;
    FirebaseUser user;
    public myordadap(@NonNull FirebaseRecyclerOptions<addata> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull final myordadap.myviewholder holder, final int position, @NonNull final addata model) {
        Auth=FirebaseAuth.getInstance();
        user=Auth.getCurrentUser();

        reference = FirebaseDatabase.getInstance().getReference().child("myorder");
        ref = FirebaseDatabase.getInstance().getReference().child("orders");
        holder.name.setText(model.getName());
        holder.price.setText(model.getTotal());
        holder.qty.setText(model.getQty());
        holder.cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String id1=model.getOrdid();
                ref.child(id1).child("value").setValue("order cancelled");
                reference.child(user.getUid()).child(model.getOrdid()).removeValue();


            }
        });
        holder.ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id1=model.getOrdid();
                ref.child(id1).child("value").setValue("order delivered");
                reference.child(user.getUid()).child(model.getOrdid()).removeValue();
            }
        });

    }
    public myordadap.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.myord,parent,false);
        return new myordadap.myviewholder(view);
    }

    class myviewholder extends RecyclerView.ViewHolder{
        TextView name,price,qty;
        Button cancel,ok;
        View v;
        public myviewholder(@NonNull final View itemView) {
            super(itemView);

            name=(TextView)itemView.findViewById(R.id.pname);
            price=(TextView)itemView.findViewById(R.id.total);
            qty=(TextView)itemView.findViewById(R.id.qty);
            cancel=(Button) itemView.findViewById(R.id.corder);
            ok=(Button)itemView.findViewById(R.id.ok);
            v=itemView;

        }

    }
}
