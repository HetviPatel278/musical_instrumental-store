package com.example.ecommerce;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.telecom.Call;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class myadapter extends FirebaseRecyclerAdapter<addata,myadapter.viewholder> {

    DatabaseReference reference;
    public myadapter(@NonNull FirebaseRecyclerOptions<addata> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull final viewholder holder, final int position, @NonNull final addata model) {
        reference= FirebaseDatabase.getInstance().getReference().child("products");
        holder.name.setText(model.getName());
        holder.price.setText(model.getPrice());
        holder.desc.setText(model.getDescription());
        holder.stock.setText(model.getStock());
        reference.child(model.getProdid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    String img=snapshot.child("image").getValue().toString();
                    Glide.with(holder.i1.getContext()).load(img).into(holder.i1);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



       holder.v.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent=new Intent(v.getContext(),details.class);
               intent.putExtra("prodid",getRef(position).getKey());
               v.getContext().startActivity(intent);
           }
       });


         }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow,parent,false);
        return new viewholder(view);
    }

    class viewholder extends RecyclerView.ViewHolder{
        ImageView i1;
        TextView name,price,desc,stock;
        View v;
        public viewholder(@NonNull final View itemView) {
            super(itemView);

            name=(TextView)itemView.findViewById(R.id.prod_name);
            price=(TextView)itemView.findViewById(R.id.price);
            desc=(TextView)itemView.findViewById(R.id.prod_desc);
            stock=(TextView)itemView.findViewById(R.id.avail);
            i1=(ImageView)itemView.findViewById(R.id.im1);
            v=itemView;

        }

    }


}
