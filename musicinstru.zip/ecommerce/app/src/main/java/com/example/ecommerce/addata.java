package com.example.ecommerce;

public class addata {
    String prodid;
    String name;
    String price;
    String description;
    String features;
    String imageurl;
    String number;
    String addr;
    String ordid;
    String qty;
    String total;
    String uname;
    String date;
    String stock;
    String value;
    public addata(String prodid,String name,String price,String description,String features,String stock){
        this.prodid=prodid;
        this.name=name;
        this.price=price;
        this.description=description;
        this.features=features;
        this.stock=stock;
    }
    public addata(){

    }
    public addata(String imageurl){
        this.imageurl=imageurl;
    }

    public addata(String addr,String number,String name,String ordid,String qty,String total,String uname,String date){
        this.addr=addr;
        this.number=number;
        this.name=name;
        this.ordid=ordid;
        this.qty=qty;
        this.total=total;
        this.uname=uname;
        this.date=date;
    }
    public addata(String name,String total,String qty,String ordid){
        this.name=name;
        this.total=total;
        this.qty=qty;
        this.ordid=ordid;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getOrdid() {
        return ordid;
    }

    public void setOrdid(String ordid) {
        this.ordid = ordid;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }


    public String getProdid() {
        return prodid;
    }

    public void setProdid(String prodid) {
        this.prodid = prodid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFeatures() {
        return features;
    }

    public void setFeatures(String features) {
        this.features = features;
    }
    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }
}
