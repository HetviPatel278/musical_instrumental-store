package com.example.ecommerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class userpage extends AppCompatActivity {
RecyclerView recview;
EditText search;
Button my,logout;
DatabaseReference mdatabase;
FirebaseUser user;
FirebaseAuth Auth;
myadapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userpage);
        search=(EditText)findViewById(R.id.search);
        my=(Button)findViewById(R.id.my);
        logout=(Button)findViewById(R.id.logou);
        my.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(userpage.this,myorder.class);
                startActivity(i);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mStartActivity = new Intent(userpage.this, MainActivity.class);
                int mPendingIntentId = 123456;
                PendingIntent mPendingIntent = PendingIntent.getActivity(userpage.this, mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
                AlarmManager mgr = (AlarmManager)userpage.this.getSystemService(Context.ALARM_SERVICE);
                mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
                System.exit(0);
            }
        });
        recview=(RecyclerView)findViewById(R.id.recview);
        recview.setLayoutManager(new LinearLayoutManager(this));
        mdatabase=FirebaseDatabase.getInstance().getReference().child("products");
            FirebaseRecyclerOptions<addata> options =
                    new FirebaseRecyclerOptions.Builder<addata>()
                            .setQuery(FirebaseDatabase.getInstance().getReference().child("products"), addata.class)
                            .build();

            adapter=new myadapter(options);
            recview.setAdapter(adapter);

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void afterTextChanged(Editable editable) {
                //after the change calling the method and passing the search input
                filter(editable.toString());
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }
    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
    public void filter(String text){

        Query firebaseSearchQuery = mdatabase.orderByChild("name").startAt(text).endAt(text + "\uf8ff");
        FirebaseRecyclerOptions<addata> options1 =
                new FirebaseRecyclerOptions.Builder<addata>()
                        .setQuery(firebaseSearchQuery, addata.class)
                        .setLifecycleOwner(this)
                        .build();
        adapter=new myadapter(options1);
        recview.setAdapter(adapter);
    }
}