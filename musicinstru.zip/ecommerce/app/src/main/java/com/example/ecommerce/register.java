package com.example.ecommerce;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class register extends AppCompatActivity {
EditText firstname,lastname,email,password;
Button register;
FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        firstname=(EditText)findViewById(R.id.firstname);
        lastname=(EditText)findViewById(R.id.lastname);
        register=(Button)findViewById(R.id.register);
        email=(EditText) findViewById(R.id.email);
        password=(EditText)findViewById(R.id.password);
        firebaseAuth=FirebaseAuth.getInstance();

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
    }
    public void add(){
        String fname=firstname.getText().toString().trim();
        String lname=lastname.getText().toString().trim();
        String emai=email.getText().toString().trim();
        String pass=password.getText().toString().trim();

        if(fname.isEmpty()){
            firstname.setError("please enter Firstname");
            firstname.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(emai).matches()){
            email.setError("please enter valid email address");
            email.requestFocus();
            return;
        }
        if(lname.isEmpty()){
            lastname.setError("enter lastname");
            lastname.requestFocus();
            return;
        }

        if(pass.length()<6){
            password.setError("minimum length of password should be 6");
            password.requestFocus();
            return;

        }


        firebaseAuth.createUserWithEmailAndPassword(emai, pass)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(register.this," registered successfully:",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(register.this, userpage.class));

                        }
                        else {
                            FirebaseAuthException e=(FirebaseAuthException)task.getException();
                            Toast.makeText(register.this,"failed registered successfully:"+e.getMessage(),Toast.LENGTH_SHORT).show();

                        }
                    }
                });

    }

}
