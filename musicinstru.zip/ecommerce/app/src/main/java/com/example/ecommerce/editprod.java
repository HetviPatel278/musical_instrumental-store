package com.example.ecommerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.EditText;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class editprod extends AppCompatActivity {
    RecyclerView recyclrview;
    DatabaseReference mdatabase;
    editadap adapte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editprod);
        recyclrview=(RecyclerView)findViewById(R.id.recyclrview);
        recyclrview.setLayoutManager(new LinearLayoutManager(this));
        FirebaseRecyclerOptions<addata> opt =
                new FirebaseRecyclerOptions.Builder<addata>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("products"), addata.class)
                        .build();
        adapte=new editadap(opt);
        recyclrview.setAdapter(adapte);
    }
    protected void onStart() {
        super.onStart();
        adapte.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapte.stopListening();
    }
}

