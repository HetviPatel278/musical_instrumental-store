package com.example.ecommerce;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class sellerlogin extends AppCompatActivity {
    EditText suserid,spass;
    Button slogin;
    FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sellerlogin);
        suserid=(EditText)findViewById(R.id.suserid);
        spass=(EditText)findViewById(R.id.spass);
        slogin=(Button)findViewById(R.id.slogin);
        auth=FirebaseAuth.getInstance();
        slogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

    }
    public void login(){
        String u_id=suserid.getText().toString().trim();
        String u_pass=spass.getText().toString().trim();

        if(u_id.isEmpty()){
            suserid.setError("please enter email");
            suserid.requestFocus();
            return;
        }

        if(u_pass.isEmpty()){
            spass.setError("enter password");
            spass.requestFocus();
            return;
        }
        if(u_pass.length()<6){
            spass.setError("minimum length of password should be 6");
            spass.requestFocus();
            return;

        }
        if(u_id.equals("admin") && u_pass.equals("admin123")){
            Toast.makeText(sellerlogin.this, "login successfully done", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(sellerlogin.this, sellerpage.class));
        }
        else {
            Toast.makeText(sellerlogin.this, "enter correct username and password", Toast.LENGTH_SHORT).show();
        }

    }
}
