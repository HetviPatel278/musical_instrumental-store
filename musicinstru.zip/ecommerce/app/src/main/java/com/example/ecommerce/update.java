package com.example.ecommerce;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
public class update extends AppCompatActivity {
    private final int IMG1=1;
    private final int IMG2=2;
    StorageReference mStorageRef;
    ImageView img,img2;
    Button upimg;
    EditText prod_id,price,prod_desc,feature,name,stock;
    Uri imageuri,imguri2;
    FirebaseUser user;
    FirebaseAuth Auth;
    DatabaseReference dbadd,reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addprod);
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        dbadd= db.getReference("products");
        reference= db.getReference("products1");
        upimg=(Button)findViewById(R.id.upimg);
        img=(ImageView)findViewById(R.id.img);
        img2=(ImageView)findViewById(R.id.img2);
        final String prodid=getIntent().getStringExtra("prodid");
        name=(EditText)findViewById(R.id.prod_name);
        prod_id=(EditText)findViewById(R.id.prod_id);
        price=(EditText)findViewById(R.id.price);
        prod_desc=(EditText)findViewById(R.id.prod_desc);
        feature=(EditText)findViewById(R.id.feat);
        stock=(EditText)findViewById(R.id.stock);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(Intent.createChooser(new Intent().setAction(Intent.ACTION_GET_CONTENT).setType("image/*"),"select image"),IMG1);
            }
        });
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(Intent.createChooser(new Intent().setAction(Intent.ACTION_GET_CONTENT).setType("image/*"),"select"),IMG2);
            }
        });
        upimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upload();
                add();
            }
        });

        dbadd.child(prodid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    String namei=snapshot.child("name").getValue().toString();
                    String pricei=snapshot.child("price").getValue().toString();
                    String descr=snapshot.child("description").getValue().toString();
                    String featu=snapshot.child("features").getValue().toString();
                    String stoc=snapshot.child("stock").getValue().toString();
                    String proid=snapshot.child("prodid").getValue().toString();
                    String img1=snapshot.child("image").getValue().toString();
                    String im2=snapshot.child("image2").getValue().toString();
                    prod_id.setText(proid);
                    name.setText(namei);
                    price.setText(pricei);
                    prod_desc.setText(descr);
                    feature.setText(featu);
                    stock.setText(stoc);
                    Picasso.get().load(img1).into(img);
                    Picasso.get().load(im2).into(img2);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    public void add(){
        final String p_id=prod_id.getText().toString().trim();
        final String p_name=name.getText().toString().trim();
        final String pri=price.getText().toString().trim();
        final String desc=prod_desc.getText().toString().trim();
        final String feat=feature.getText().toString().trim();
        final String stok=stock.getText().toString().trim();
       // addata a = new addata(p_id,p_name,pri, desc, feat);
        dbadd.child(p_id).child("name").setValue(p_name);
        dbadd.child(p_id).child("price").setValue(pri);
        dbadd.child(p_id).child("description").setValue(desc);
        dbadd.child(p_id).child("features").setValue(feat);
        dbadd.child(p_id).child("stock").setValue(stok);
        Toast.makeText(update.this, "updated", Toast.LENGTH_SHORT).show();


    }
    private String getExtension(Uri uri){
        ContentResolver cr = getContentResolver();
        MimeTypeMap mimeTypeMap=MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));
    }
    private void upload(){
        final String p_id=prod_id.getText().toString().trim();
        mStorageRef= FirebaseStorage.getInstance().getReference("images").child(p_id);
        final StorageReference Ref=mStorageRef.child(System.currentTimeMillis()+"."+getExtension(imageuri));
        Ref.putFile(imageuri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                Uri downloadUrl = uri;
                                String fileUrl = downloadUrl.toString();
                                dbadd.child(p_id).child("image").setValue(fileUrl);
                            }
                        });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                    }
                });

        final StorageReference Re=mStorageRef.child(System.currentTimeMillis()+"."+getExtension(imguri2));
        Re.putFile(imguri2)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                        Re.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                Uri downloadUrl2 = uri;
                                String fileUrl2 = downloadUrl2.toString();
                                dbadd.child(p_id).child("image2").setValue(fileUrl2);

                            }
                        });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                    }
                });
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == IMG1 && resultCode == RESULT_OK){
            imageuri = data.getData();
            if(imageuri!=null){
                img.setImageURI(imageuri);
            }
        }
        else if(requestCode == IMG2 && resultCode == RESULT_OK){
            imguri2 = data.getData();
            if (imguri2!=null){
                img2.setImageURI(imguri2);

            }
        }

    }
}
