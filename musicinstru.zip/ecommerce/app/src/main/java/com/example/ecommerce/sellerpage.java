package com.example.ecommerce;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class sellerpage extends AppCompatActivity {
Button add,order,edit,logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sellerpage);
        add=(Button)findViewById(R.id.addprod);
        edit=(Button)findViewById(R.id.edit);
        order=(Button)findViewById(R.id.btn_order);
        logout=(Button)findViewById(R.id.logout);
        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ord();
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edi();
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refresh();
            }
        });
    }

    public void refresh(){
        Intent mStartActivity = new Intent(sellerpage.this, MainActivity.class);
        int mPendingIntentId = 123456;
        PendingIntent mPendingIntent = PendingIntent.getActivity(sellerpage.this, mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager mgr = (AlarmManager)sellerpage.this.getSystemService(Context.ALARM_SERVICE);
        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
        System.exit(0);

    }
    public void add(){
        Intent intent = new Intent(this, addprod.class);
        startActivity(intent);
    }
    public void ord(){
        Intent intent = new Intent(this, orderpage.class);
        startActivity(intent);
    }
    public void edi(){
        Intent intent = new Intent(this, editprod.class);
        startActivity(intent);
    }

}
