package com.example.ecommerce;

import android.content.Intent;
import android.net.Uri;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class orderadap extends FirebaseRecyclerAdapter<addata,orderadap.myviewholder> {
    DatabaseReference db,ref;

    public orderadap(@NonNull FirebaseRecyclerOptions<addata> options) {
        super(options);
    }

    protected void onBindViewHolder(@NonNull orderadap.myviewholder holder, final int position, @NonNull final addata model){

        holder.name.setText(model.getName());
        holder.address.setText(model.getAddr());
        holder.number.setText(model.getNumber());
        holder.qty.setText(model.getQty());
        holder.total.setText(model.getTotal());
        holder.uname.setText(model.getUname());
        holder.date.setText(model.getDate());
        holder.cancel.setText(model.getValue());
      /*  holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                db= FirebaseDatabase.getInstance().getReference("orders").child(model.getOrdid());
                db.removeValue();
                Toast.makeText(v.getContext(),"Confirmed",Toast.LENGTH_LONG).show();
            }
        });*/
        holder.number.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String smsNumber = model.getNumber();
                String txt = model.getAddr();
                String qty=model.getQty();
                String Total=model.getTotal();
                String unam=model.getUname();
                String smsText = "hello, "+unam+"\n your order is confirmed\n,your Package will be delivered in 4 to 5 days on this address: "+txt+" Quantity is:"+qty+
                        "  Total bill:"+Total;

                Uri uri = Uri.parse("smsto:" + smsNumber);
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                intent.putExtra("sms_body", smsText);
                v.getContext().startActivity(intent);
            }
        });
    }

    @NonNull
    @Override
    public orderadap.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.orderview,parent,false);
        return new myviewholder(view);
    }


    class myviewholder extends RecyclerView.ViewHolder{

        TextView name,address,number,qty,total,uname,date,cancel;
        Button btn;
        //View v;
        public myviewholder(@NonNull final View itemView){
            super(itemView);
            cancel=(TextView) itemView.findViewById(R.id.cancel);
            name=(TextView)itemView.findViewById(R.id.name);
            address=(TextView)itemView.findViewById(R.id.address);
            number=(TextView)itemView.findViewById(R.id.number);
            qty=(TextView)itemView.findViewById(R.id.qty);
            uname=(TextView)itemView.findViewById(R.id.unam);
            total=(TextView)itemView.findViewById(R.id.total);
            date=(TextView)itemView.findViewById(R.id.date);
          //  v=itemView;

        }
    }
}

