package com.example.ecommerce;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class details extends AppCompatActivity {

ImageView imge,img2;
TextView namei,description,pricei,features,qty,stock;
EditText address,number,uname;
DatabaseReference reference;
DatabaseReference ref,myorder;
Button btn_order,inc,dec;
FirebaseAuth Auth;
FirebaseUser user;
    int minteger=1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Auth=FirebaseAuth.getInstance();
        user=Auth.getCurrentUser();
        namei=(TextView)findViewById(R.id.name1);
        pricei=(TextView)findViewById(R.id.price1);
        description=(TextView)findViewById(R.id.desc1);
        features=(TextView)findViewById(R.id.feat1);
        qty=(TextView)findViewById(R.id.qty);
        stock=(TextView)findViewById(R.id.stock);
        inc=(Button)findViewById(R.id.inc);
        dec=(Button)findViewById(R.id.dec);
        imge=(ImageView)findViewById(R.id.imge1);
        img2=(ImageView)findViewById(R.id.imge2);
        final String prodid=getIntent().getStringExtra("prodid");
        uname=(EditText)findViewById(R.id.uname);
        address=(EditText)findViewById(R.id.addrss);
        number=(EditText)findViewById(R.id.emai);
        ref=FirebaseDatabase.getInstance().getReference().child("orders");
        myorder=FirebaseDatabase.getInstance().getReference().child("myorder");
        btn_order=(Button)findViewById(R.id.order1);
        reference= FirebaseDatabase.getInstance().getReference().child("products");


        btn_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String unam=uname.getText().toString().trim();
                final String addr=address.getText().toString().trim();
                final String num=number.getText().toString().trim();
                final String name=namei.getText().toString().trim();
                String stoc=stock.getText().toString().trim();
                String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                String key = ref.push().getKey();
                if(!TextUtils.isEmpty(addr)){
                    if(!TextUtils.isEmpty(num)){
                        int qt=Integer.parseInt(qty.getText().toString());
                        int price=Integer.parseInt(pricei.getText().toString());
                        int total=price*qt;
                        String tot=String.valueOf(total);
                        String qaunt=String.valueOf(qt);
                        if(qt<=Integer.parseInt(stoc)&&qt>=1) {
                        int p=Integer.parseInt(stoc) - qt;
                        String updstock=String.valueOf(p);
                            reference.child(prodid).child("stock").setValue(updstock);
                            addata ad=new addata(addr,num,name,key,qaunt,tot,unam,date);
                            ref.child(key).setValue(ad);
                            addata add=new addata(name,tot,qaunt,key);
                            myorder.child(user.getUid()).child(key).setValue(add);

                            Toast.makeText(details.this, "order placed", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(details.this, "Please enter valid quantity no. only "+stoc+"is left", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(details.this,"enter email",Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(details.this,"enter address",Toast.LENGTH_SHORT).show();
                }

            }
        });
        reference.child(prodid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if(snapshot.exists()){
                    String name=snapshot.child("name").getValue().toString();
                    String price=snapshot.child("price").getValue().toString();
                    String descr=snapshot.child("description").getValue().toString();
                    String featu=snapshot.child("features").getValue().toString();
                    String img=snapshot.child("image").getValue().toString();
                    String im2=snapshot.child("image2").getValue().toString();
                    String sto=snapshot.child("stock").getValue().toString();
                    namei.setText(name);
                    pricei.setText(price);
                    description.setText(descr);
                    features.setText(featu);
                    stock.setText(sto);
                    Picasso.get().load(img).into(imge);
                    Picasso.get().load(im2).into(img2);

                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    public void increaseInteger(View view) {
        minteger = minteger + 1;
        display(minteger);

    }public void decreaseInteger(View view) {
        minteger = minteger - 1;
        display(minteger);
    }
    private void display(int number) {
        TextView displayInteger = (TextView) findViewById(
                R.id.qty);
        displayInteger.setText("" + number);
    }

}
